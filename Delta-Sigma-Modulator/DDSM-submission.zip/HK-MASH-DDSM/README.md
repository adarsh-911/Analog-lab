DDSM\Delta-Sigma-Modulator-master\HK-MASH-DDSM> iverilog -o tb.out rtl/*.v tb/tb_hk_mash111.v
DDSM\Delta-Sigma-Modulator-master\HK-MASH-DDSM> vvp tb.out    